package tests;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import pages.DeleteComputerPage;

import pages.SearchComputerPage;

//TC4: Verified an computer is deleted
public class TC4_DeleteComputerNameTest extends TestBase {
	
	private String computernamedeleted = "Trion 500";
	String expectedAlertMessage ="Done! Computer has been deleted";
	@Test
	public void deleteComputerNameSucessfully() {
		DeleteComputerPage deletecomputerpage = PageFactory.initElements(driver, DeleteComputerPage.class);
		SearchComputerPage searchcomputerpage = PageFactory.initElements(driver, SearchComputerPage.class);
		searchcomputerpage.inputKeyword(computernamedeleted);
		searchcomputerpage.clickSearch();
		deletecomputerpage.editClick();
		deletecomputerpage.deleteClick();
		String actualAlertMessage = deletecomputerpage.getAlertMessage();
		deletecomputerpage.verifiedComputerDeleted(actualAlertMessage, expectedAlertMessage);
	}
}
