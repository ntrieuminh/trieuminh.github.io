package tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import pages.AddNewComputerPage;

public class TC2_AddNewComputerNameTest extends TestBase {

	private String computername = "Helios 300";
	private String introduceddate = "2019-11-01";
	private String discontinueddate = "2019-11-05";

	// TC2: Verify a new computer is added successfully
	@Test
	public void addComputerSuccessfully() {
		AddNewComputerPage addcomputer = PageFactory.initElements(driver, AddNewComputerPage.class);
		addcomputer.clickAdd();
		addcomputer.inputComputerName(computername);
		addcomputer.inputIntroducedDate(introduceddate);
		addcomputer.inputDiscontinuedDate(discontinueddate);
		addcomputer.selectCompany();
		addcomputer.clickCreate();
		String expectedAlertMessage = "Done! Computer " + computername + " has been created";
		String actualAlertMessage = addcomputer.getAlertMessage();
		addcomputer.verifiedComputerNameCreated(actualAlertMessage, expectedAlertMessage);
	}
}
