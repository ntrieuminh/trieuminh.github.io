package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.support.How;
import org.testng.Assert;

public class SearchComputerPage {

	WebDriver driver;

	public SearchComputerPage(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(how = How.XPATH, using = "//input[@id='searchbox']")
	WebElement searchBox;

	@FindBy(how = How.XPATH, using = "//input[contains(@value,'Filter by name')]")
	WebElement searchButton;

	public void inputKeyword(String keyword) {
		searchBox.sendKeys(keyword);
	}

	public void clickSearch() {
		searchButton.click();
	}

	public void getAndCheckComputerName(String keyword) {
		String non_upper_kw = keyword.toLowerCase();
		List<WebElement> listOfElements = driver.findElements(By.xpath("//*[@id='main']/table/tbody//tr/td[1]/*"));
		for (int i = 1; i < listOfElements.size(); i++) {
			String strItm = listOfElements.get(i).getText();
			String non_upper_strItm = strItm.toLowerCase();
			System.out.println("\nstrItm " + i + " " + strItm);

			if(non_upper_strItm.contains(non_upper_kw))
			{
				System.out.println(">>>> SUSCCEED");
			}
			else
			{
				System.out.println(">>>> FAILED");
				Assert.fail();		
			}
		}
	}
	public void getAndCheckComputerNameFailed(String keyword) {
		List<WebElement> listOfElements = driver.findElements(By.xpath("//*[@id='main']/table/tbody//tr/td[1]/*"));
		for (int i = 1; i < listOfElements.size(); i++) {
			String strItm = listOfElements.get(i).getText();
			System.out.println("\nstrItm " + i + " " + strItm);
			if(!strItm.contains(keyword)==true)
			{
				Assert.fail();
			}
		}
	}

}
