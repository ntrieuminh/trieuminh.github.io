package pages;

import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AddNewComputerPage {

	WebDriver driver;

	public AddNewComputerPage(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(how = How.XPATH, using = "//*[@id='add']")
	WebElement addNewComputer;

	@FindBy(how = How.XPATH, using = "//input[@id='name']")
	WebElement computerName;

	@FindBy(how = How.XPATH, using = "//input[@id='introduced']")
	WebElement introducedDate;

	@FindBy(how = How.XPATH, using = "//input[@id='discontinued']")
	WebElement discontinuedDate;

	@FindBy(how = How.XPATH, using = "//select[@name='company']")
	WebElement drpCompany;

	@FindBy(how = How.XPATH, using = "//input[@class='btn primary']")
	WebElement createComputer;

	@FindBy(how = How.XPATH, using = "//div[@class='alert-message warning']")
	WebElement alertMessage;

	public void clickAdd() {
		addNewComputer.click();
	}

	public void clickCreate() {
		createComputer.click();
	}

	public String getAlertMessage() {
		return alertMessage.getText();

	}

	public void inputComputerName(String cName) {
		computerName.sendKeys(cName);
	}

	public void inputIntroducedDate(String iDate) {
		introducedDate.sendKeys(iDate);
	}

	public void inputDiscontinuedDate(String dDate) {
		discontinuedDate.sendKeys(dDate);
	}

	public void selectCompany() {
		drpCompany.click();
		Select selectCompany = new Select(drpCompany);
		selectCompany.selectByIndex(1);
	}

	public void verifiedComputerNameCreated(String actualAlertMessage, String expectedAlertMessage) {
		assertEquals(actualAlertMessage, expectedAlertMessage);
	}

}
