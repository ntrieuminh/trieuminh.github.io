package pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class DeleteComputerPage {
	WebDriver driver;

	public DeleteComputerPage(WebDriver driver) {
		this.driver = driver;
	}
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Trion 500')]")
	WebElement editComputer;
	
	@FindBy(how = How.XPATH, using = "//input[@class='btn danger']")
	WebElement deleteComputer;

	@FindBy(how = How.XPATH, using = "//div[@class='alert-message warning']")
	WebElement alertMessage;
	
	public void editClick()
	{
		editComputer.click();
	}
	public void deleteClick()
	{
		deleteComputer.click();
	}
	public String getAlertMessage() {
		return alertMessage.getText();
	}
	public void verifiedComputerDeleted(String actualAlertMessage, String expectedAlertMessage )
	{
		assertEquals(actualAlertMessage,expectedAlertMessage);

	}

}
