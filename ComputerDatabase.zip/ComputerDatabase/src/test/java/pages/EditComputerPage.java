package pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class EditComputerPage {

	WebDriver driver;

	public EditComputerPage(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Helios 300')]")
	WebElement editComputer;
	
	@FindBy(how = How.XPATH, using = "//input[@id='name']")
	WebElement computerName;

	@FindBy(how = How.XPATH, using = "//input[@id='introduced']")
	WebElement introducedDate;

	@FindBy(how = How.XPATH, using = "//input[@id='discontinued']")
	WebElement discontinuedDate;

	@FindBy(how = How.XPATH, using = "//select[@name='company']")
	WebElement drpCompany;

	@FindBy(how = How.XPATH, using = "//input[@class='btn primary']")
	WebElement saveComputer;

	@FindBy(how = How.XPATH, using = "//div[@class='alert-message warning']")
	WebElement alertMessage;

		
public void Editclick()
{
	editComputer.click();
}
public void Saveclick()
{
	saveComputer.click();
}

public void inputComputerName(String cName) {
	computerName.clear();
	computerName.sendKeys(cName);
}

public void inputIntroducedDate(String iDate) {
	introducedDate.clear();
	introducedDate.sendKeys(iDate);
}

public void inputDiscontinuedDate(String dDate) {
	discontinuedDate.clear();
	discontinuedDate.sendKeys(dDate);
}

public String getAlertMessage() {
	return alertMessage.getText();
}

public void selectCompany() {
	drpCompany.click();
	Select selectCompany = new Select(drpCompany);
	selectCompany.selectByIndex(3);
}
public void verifiedComputerNameEdited(String actualAlertMessage, String expectedAlertMessage )
{
	assertEquals(actualAlertMessage,expectedAlertMessage);

}
}