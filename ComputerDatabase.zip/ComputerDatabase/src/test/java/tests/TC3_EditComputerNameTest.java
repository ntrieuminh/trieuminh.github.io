package tests;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import pages.EditComputerPage;
import pages.SearchComputerPage;

public class TC3_EditComputerNameTest extends TestBase {
	
	private String computernameadded = "Helios 300";
	private String computernameedit = "Trion 500";
	private String introduceddate = "2019-12-01";
	private String discontinueddate = "2019-12-05";
	// TC3: Verify an existing computer is edited successfully
	@Test
	public void editComputerNameSucessfully() {
		SearchComputerPage computerdatabasepage = PageFactory.initElements(driver, SearchComputerPage.class);
		EditComputerPage editComputer = PageFactory.initElements(driver, EditComputerPage.class);
		computerdatabasepage.inputKeyword(computernameadded);
		computerdatabasepage.clickSearch();
		editComputer.Editclick();
		editComputer.inputComputerName(computernameedit);
		editComputer.inputIntroducedDate(introduceddate);
		editComputer.inputDiscontinuedDate(discontinueddate);
		editComputer.selectCompany();
		editComputer.Saveclick();
		String expectedAlertMessage = "Done! Computer " + computernameedit + " has been updated";
		String actualAlertMessage = editComputer.getAlertMessage();
		editComputer.verifiedComputerNameEdited(actualAlertMessage, expectedAlertMessage);

	}
}
