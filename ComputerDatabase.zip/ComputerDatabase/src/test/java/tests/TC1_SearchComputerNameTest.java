package tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import pages.SearchComputerPage;

public class TC1_SearchComputerNameTest extends TestBase {

	private String kw = "AR";
	//TC1: Verified a computer is searched successfully
	@Test
	public void testSearchComputerName() throws Exception {
		SearchComputerPage computerdatabasepage = PageFactory.initElements(driver, SearchComputerPage.class);
		computerdatabasepage.inputKeyword(kw);
		computerdatabasepage.clickSearch();
		computerdatabasepage.getAndCheckComputerName(kw);

	}
}
