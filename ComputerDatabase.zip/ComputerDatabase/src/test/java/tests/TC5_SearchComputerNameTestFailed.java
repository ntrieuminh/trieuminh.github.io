package tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import pages.SearchComputerPage;

public class TC5_SearchComputerNameTestFailed  extends TestBase {
	private String kw = "AR";
  @Test
  public void testSearchComputerNameFailed() throws Exception {
		SearchComputerPage computerdatabasepage = PageFactory.initElements(driver, SearchComputerPage.class);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		computerdatabasepage.inputKeyword(kw);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		computerdatabasepage.clickSearch();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		computerdatabasepage.getAndCheckComputerNameFailed(kw);

	}
}
